import React, { useState, useMemo } from 'react';
import { Search, MapPin, Tag, Utensils, Award, Clock, ArrowRight, Compass, ShieldAlert, Heart } from 'lucide-react';
import { Booth } from '../types';
import { BOOTHS } from '../data';

interface BoothListProps {
  currentHour: number;
  onGoToMapWithBooth: (boothId: string) => void;
}

export default function BoothList({ currentHour, onGoToMapWithBooth }: BoothListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedZone, setSelectedZone] = useState<'ALL' | 'A' | 'B' | 'C'>('ALL');
  const [favorites, setFavorites] = useState<string[]>([]);

  // Check if booth is open at current simulated hour
  const isBoothOpenNow = (booth: Booth) => {
    return currentHour >= booth.startHour && currentHour < booth.endHour;
  };

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const filteredBooths = useMemo(() => {
    return BOOTHS.filter((booth) => {
      // Zone match
      const zoneMatch = selectedZone === 'ALL' || booth.zone === selectedZone;
      
      // Search match
      const lowerSearch = searchTerm.toLowerCase();
      const searchMatch = 
        booth.name.toLowerCase().includes(lowerSearch) ||
        booth.description.toLowerCase().includes(lowerSearch) ||
        booth.tags.some(t => t.toLowerCase().includes(lowerSearch)) ||
        booth.locationDesc.toLowerCase().includes(lowerSearch);

      return zoneMatch && searchMatch;
    });
  }, [selectedZone, searchTerm]);

  return (
    <div className="space-y-4">
      {/* Search and Filters */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 space-y-3.5">
        <div className="relative">
          <Search className="absolute left-4 top-3.5 w-4.5 h-4.5 text-slate-400" />
          <input
            type="text"
            placeholder="부스 이름, 먹거리, 체험(다트, 향수) 검색..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-11 pr-4 py-3 text-sm text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-500/25 focus:border-rose-500 transition-all font-medium"
            id="booth-search-input"
          />
        </div>

        <div className="flex bg-slate-100 p-1 rounded-2xl">
          {(['ALL', 'A', 'B', 'C'] as const).map((z) => (
            <button
              key={z}
              onClick={() => setSelectedZone(z)}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                selectedZone === z
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              {z === 'ALL' ? '전체 부스' : `${z}구역`}
            </button>
          ))}
        </div>

        <div className="flex items-center justify-between text-xs text-slate-500 font-semibold px-1">
          <span>검색된 부스: {filteredBooths.length}개</span>
          {favorites.length > 0 && (
            <button 
              onClick={() => {
                setSearchTerm('');
                setSelectedZone('ALL');
                // Could act as favorite filter toggle
              }}
              className="text-rose-500 flex items-center gap-1"
            >
              <span>스크랩 부스 {favorites.length}개</span>
            </button>
          )}
        </div>
      </div>

      {/* Booth Grid / List */}
      {filteredBooths.length > 0 ? (
        <div className="space-y-4">
          {filteredBooths.map((booth) => {
            const isOpen = isBoothOpenNow(booth);
            const isFav = favorites.includes(booth.id);

            return (
              <div
                key={booth.id}
                className="bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all overflow-hidden relative group"
              >
                {/* Zone background corner indicator */}
                <div className={`absolute top-0 left-0 w-2.5 h-full ${
                  booth.zone === 'A'
                    ? 'bg-emerald-500'
                    : booth.zone === 'B'
                    ? 'bg-amber-500'
                    : 'bg-indigo-500'
                }`}></div>

                <div className="p-5 pl-7">
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                          booth.zone === 'A'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-100/50'
                            : booth.zone === 'B'
                            ? 'bg-amber-50 text-amber-700 border border-amber-100/50'
                            : 'bg-indigo-50 text-indigo-700 border border-indigo-100/50'
                        }`}>
                          {booth.zone}구역 부스
                        </span>
                        
                        <span className={`text-[10px] px-2 py-0.5 rounded-md font-bold flex items-center gap-1 ${
                          isOpen
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-500'
                        }`}>
                          <Clock className="w-2.5 h-2.5" />
                          {isOpen ? '영업중' : '운영 준비/종료'}
                        </span>
                      </div>

                      <h4 className="font-extrabold text-slate-800 text-base flex items-center gap-1.5 pt-0.5">
                        {booth.name}
                      </h4>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={(e) => toggleFavorite(booth.id, e)}
                        className={`p-2 rounded-full transition-all border ${
                          isFav 
                            ? 'bg-rose-50 border-rose-100 text-rose-500' 
                            : 'bg-slate-50 border-slate-100 text-slate-400 hover:text-slate-600'
                        }`}
                        title="즐겨찾기 추가"
                      >
                        <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500' : ''}`} />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                    {booth.description}
                  </p>

                  {/* Menu/Activity Detail breakdown */}
                  <div className="mt-3 bg-slate-50 rounded-2xl p-3 border border-slate-100 space-y-1.5">
                    <span className="text-[10px] font-bold text-slate-400 block mb-0.5">🍰 제공 품목 / 대표 추천</span>
                    {booth.menuOrActivity.slice(0, 3).map((item, idx) => (
                      <div key={idx} className="flex justify-between text-xs text-slate-600 font-medium">
                        <span>• {item.split(' - ')[0]}</span>
                        <span className="font-bold text-slate-800">{item.split(' - ')[1] || '체험'}</span>
                      </div>
                    ))}
                    {booth.menuOrActivity.length > 3 && (
                      <div className="text-[10px] text-slate-400 text-right font-medium">
                        그 외 {booth.menuOrActivity.length - 3}개 품목 더보기
                      </div>
                    )}
                  </div>

                  {/* Footer links */}
                  <div className="mt-4 pt-3.5 border-t border-slate-100 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium">
                      <Compass className="w-3.5 h-3.5 text-slate-400" />
                      <span>{booth.locationDesc}</span>
                    </div>

                    <button
                      onClick={() => onGoToMapWithBooth(booth.id)}
                      className="flex items-center gap-1 text-xs font-bold text-rose-500 hover:text-rose-600 hover:underline transition-all"
                      id={`go-to-map-${booth.id}`}
                    >
                      <span>지도 위치 보기</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Tags */}
                  <div className="mt-2.5 flex flex-wrap gap-1">
                    {booth.tags.map((tag) => (
                      <span key={tag} className="text-[9px] font-bold bg-slate-100 text-slate-500 py-0.5 px-2 rounded">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-10 border border-slate-100 text-center text-slate-400 flex flex-col items-center justify-center gap-2.5">
          <ShieldAlert className="w-8 h-8 text-slate-300" />
          <h4 className="font-bold text-slate-700 text-sm">일치하는 부스가 없습니다</h4>
          <p className="text-xs">검색어나 선택 구역 지정을 다시 확인해보세요.</p>
        </div>
      )}
    </div>
  );
}
