import React from 'react';
import { Clock, Play, AlertCircle } from 'lucide-react';

interface VirtualTimeControllerProps {
  currentHour: number;
  useRealTime: boolean;
  onHourChange: (hour: number) => void;
  onToggleRealTime: (useRealTime: boolean) => void;
}

export default function VirtualTimeController({
  currentHour,
  useRealTime,
  onHourChange,
  onToggleRealTime
}: VirtualTimeControllerProps) {
  // Translate numeric hour back to a formatted string (HH:MM)
  const formatHour = (h: number) => {
    const hh = Math.floor(h);
    const mm = Math.round((h % 1) * 60);
    return `${hh.toString().padStart(2, '0')}:${mm.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-xl border border-slate-800">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-indigo-500 rounded-lg animate-pulse">
            <Clock className="w-4 h-4 text-white" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">가상 타임 컨트롤러</span>
            <span className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
              {formatHour(currentHour)} {currentHour >= 12 ? '오후' : '오전'}
            </span>
          </div>
        </div>
        
        <div className="flex gap-1.5 bg-slate-800 p-1 rounded-lg text-xs font-semibold">
          <button
            onClick={() => onToggleRealTime(true)}
            className={`px-3 py-1 rounded-md transition-all ${
              useRealTime
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            실시간
          </button>
          <button
            onClick={() => onToggleRealTime(false)}
            className={`px-3 py-1 rounded-md transition-all ${
              !useRealTime
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            시뮬레이션
          </button>
        </div>
      </div>

      {!useRealTime ? (
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <input
              type="range"
              min="9"
              max="22"
              step="0.25" // Represents 15-minute increments
              value={currentHour}
              onChange={(e) => onHourChange(parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg appearance-none"
              id="time-range-slider"
            />
          </div>
          <div className="flex justify-between text-[10px] text-slate-400 px-1 font-mono">
            <span>09:00 (시작)</span>
            <span>15:00 (낮)</span>
            <span>18:00 (노을)</span>
            <span>22:00 (야간)</span>
          </div>
        </div>
      ) : (
        <div className="bg-indigo-950/40 border border-indigo-900/40 rounded-lg p-2.5 flex items-start gap-2">
          <AlertCircle className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
          <p className="text-[11px] text-slate-300 leading-relaxed">
            현재 실제 시간을 반영하여 부스 운영 상태를 체크하고 있습니다. 
            원하는 시간대(낮/밤)로 부스 운영을 가상 확인하려면 **시뮬레이션** 모드로 전환하세요!
          </p>
        </div>
      )}
    </div>
  );
}
