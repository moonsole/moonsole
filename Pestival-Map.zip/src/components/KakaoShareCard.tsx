import React, { useState } from 'react';
import { Share2, Copy, Check, MessageSquare, Send, Users, Sparkles, X } from 'lucide-react';

interface KakaoShareCardProps {
  festivalName: string;
}

export default function KakaoShareCard({ festivalName }: KakaoShareCardProps) {
  const [friendName, setFriendName] = useState('');
  const [customMessage, setCustomMessage] = useState('야! 오늘 청춘 나래 축제 완전 대박이래! 같이 가서 맛있는 타코야끼도 먹고, 푸드트럭 돌고, 7시 반에 락 밴드 공연도 보자! 🎸🔥');
  const [copied, setCopied] = useState(false);
  const [showSimulatedModal, setShowSimulatedModal] = useState(false);
  const [selectedFriend, setSelectedFriend] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);

  const friendsList = [
    { name: '민우 (단짝 절친)', avatar: '🐳' },
    { name: '수현 (동아리 선배)', avatar: '🦊' },
    { name: '대현 (과대표)', avatar: '🦁' },
    { name: '청춘 단톡방 (15명)', avatar: '📣' }
  ];

  const fullShareText = `${friendName ? `${friendName}님! ` : ''}${customMessage}\n\n📍 실시간 축제 안내 앱 링크:\n${window.location.href}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(fullShareText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLaunchSimulation = () => {
    setShowSimulatedModal(true);
    setSendSuccess(false);
    setSelectedFriend(null);
  };

  const handleSendSimulation = (friend: string) => {
    setSelectedFriend(friend);
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      setSendSuccess(true);
      setTimeout(() => {
        setShowSimulatedModal(false);
      }, 1500);
    }, 1200);
  };

  return (
    <div className="bg-white rounded-3xl p-6 shadow-md border border-slate-100 overflow-hidden relative">
      <div className="absolute top-0 right-0 w-32 h-32 bg-amber-100 rounded-full blur-3xl opacity-60 -mr-6 -mt-6"></div>
      
      <div className="flex items-start justify-between mb-4 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 bg-[#FEE500] text-[#3c1e1e] flex items-center justify-center rounded-2xl font-black text-lg shadow-sm">
            카
          </div>
          <div>
            <h3 className="font-bold text-slate-800 text-base flex items-center gap-1.5">
              카카오톡 친구 공유
              <span className="bg-amber-100 text-amber-700 text-[10px] px-1.5 py-0.5 rounded-full font-bold">인기</span>
            </h3>
            <p className="text-xs text-slate-500">메시지를 맞춤 설정해 친구에게 초대장을 보내세요.</p>
          </div>
        </div>
      </div>

      <div className="space-y-4 relative z-10">
        <div>
          <label className="block text-xs font-bold text-slate-600 mb-1.5">친구 이름 (선택)</label>
          <input
            type="text"
            placeholder="지민이, 슬기..."
            value={friendName}
            onChange={(e) => setFriendName(e.target.value)}
            className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#FEE500]/50 transition-all font-medium"
            id="friend-name-input"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-600 mb-1.5">초대 메시지 카드로 편집</label>
          <textarea
            rows={3}
            value={customMessage}
            onChange={(e) => setCustomMessage(e.target.value)}
            className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#FEE500]/50 transition-all font-medium leading-relaxed resize-none"
            id="custom-invite-message"
          />
        </div>

        {/* Cacao Styled Message Preview */}
        <div className="bg-[#BACEE0] rounded-2xl p-4 border border-[#9bafc2] relative overflow-hidden">
          <div className="absolute top-2 right-2 flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-red-400 rounded-full"></span>
            <span className="w-1.5 h-1.5 bg-yellow-400 rounded-full"></span>
            <span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span>
          </div>
          <span className="text-[10px] text-slate-600 font-bold block mb-2 font-mono">⚡ KAKAOTALK PREVIEW</span>
          
          <div className="flex gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-sm shadow-sm">
              🎪
            </div>
            <div className="flex-1 max-w-[85%]">
              <span className="text-[10px] font-bold text-slate-700 block mb-0.5">청춘나래 가이드</span>
              
              <div className="bg-[#FFFFFF] p-3 rounded-2xl shadow-sm border border-slate-200/50">
                <p className="text-xs text-slate-800 leading-relaxed font-semibold">
                  {friendName ? <span className="text-indigo-600">@{friendName} </span> : ''}
                  {customMessage}
                </p>
                <div className="mt-3.5 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="font-bold flex items-center gap-1 text-slate-600">
                    <Sparkles className="w-3 h-3 text-yellow-500" />
                    모바일 축제 안내 앱 가기
                  </span>
                  <span className="text-[10px] text-amber-600 font-bold px-1.5 py-0.5 bg-amber-50 rounded-md">
                    초대장
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            onClick={handleCopy}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-slate-700 bg-slate-100 hover:bg-slate-200 text-xs font-bold transition-all shadow-sm active:scale-98"
            id="copy-link-btn"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-600" />
                <span>복사 완료!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-slate-500" />
                <span>메시지 링크 복사</span>
              </>
            )}
          </button>
          
          <button
            onClick={handleLaunchSimulation}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-[#3c1e1e] bg-[#FEE500] hover:bg-[#F2D400] text-xs font-bold transition-all shadow-sm active:scale-98"
            id="kakaotalk-simulate-btn"
          >
            <MessageSquare className="w-4 h-4 text-[#3c1e1e]" />
            <span>카톡으로 빠른 전송</span>
          </button>
        </div>
      </div>

      {/* Simulated Modal Dialog */}
      {showSimulatedModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="w-full max-w-sm bg-white rounded-3xl overflow-hidden shadow-2xl border border-slate-100">
            <div className="bg-[#FEE500] p-4 flex items-center justify-between dark:text-slate-900">
              <div className="flex items-center gap-2 text-[#3c1e1e]">
                <MessageSquare className="w-5 h-5 fill-[#3c1e1e]" />
                <span className="font-bold text-sm">대상의 친구 선택하기</span>
              </div>
              <button
                onClick={() => setShowSimulatedModal(false)}
                className="p-1 text-[#3c1e1e] hover:bg-[#3c1e1e]/10 rounded-full transition-all"
                id="close-simulation-modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <p className="text-xs text-slate-500 text-center">
                실제 카카오톡 API를 심사 없이 호출할 수 있도록 기획된 <br />
                <span className="font-bold text-amber-600">모의 전송 시뮬레이션</span>입니다.
              </p>

              {isSending ? (
                <div className="flex flex-col items-center justify-center py-8 space-y-3">
                  <div className="w-12 h-12 border-4 border-[#FEE500] border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-sm font-bold text-slate-700 animate-pulse">
                    {selectedFriend}님에게 공유 메시지 쏘는 중...
                  </p>
                </div>
              ) : sendSuccess ? (
                <div className="flex flex-col items-center justify-center py-8 space-y-3 text-center">
                  <div className="w-14 h-14 bg-emerald-100 text-emerald-600 flex items-center justify-center rounded-full text-2xl animate-bounce">
                    🎉
                  </div>
                  <div>
                    <p className="text-base font-bold text-slate-800">전송 성공!</p>
                    <p className="text-xs text-slate-500 mt-1">친구에게 대화 카드를 무사히 전송했습니다.</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-slate-400 block pb-1 border-b border-slate-100">
                    등록된 인메모리 대상 리스트
                  </span>
                  
                  {friendsList.map((friend) => (
                    <button
                      key={friend.name}
                      onClick={() => handleSendSimulation(friend.name)}
                      className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-all border border-slate-100 group text-left"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl bg-slate-100 w-9 h-9 flex items-center justify-center rounded-lg">
                          {friend.avatar}
                        </span>
                        <span className="text-sm font-medium text-slate-700 group-hover:text-slate-900">
                          {friend.name}
                        </span>
                      </div>
                      <Send className="w-4 h-4 text-slate-300 group-hover:text-amber-500 group-hover:translate-x-0.5 transition-all" />
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <div className="bg-slate-50 p-3.5 text-center text-[11px] text-slate-400 border-t border-slate-100">
              초대된 친구가 링크를 타고 즉시 접속할 수 있습니다.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
