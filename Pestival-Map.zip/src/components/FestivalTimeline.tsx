import React, { useState, useMemo } from 'react';
import { Clock, Music, Calendar, MapPin, CheckCircle, Flame, Star, Coffee, Sparkles } from 'lucide-react';
import { TimelineItem } from '../types';
import { TIMELINE_ITEMS } from '../data';

interface FestivalTimelineProps {
  currentHour: number;
}

export default function FestivalTimeline({ currentHour }: FestivalTimelineProps) {
  const [activeFilter, setActiveFilter] = useState<'all' | 'band' | 'booth' | 'general'>('all');

  // Filter items
  const filteredItems = useMemo(() => {
    return TIMELINE_ITEMS.filter(item => {
      if (activeFilter === 'all') return true;
      return item.type === activeFilter;
    }).sort((a, b) => a.startHour - b.startHour);
  }, [activeFilter]);

  // Determine whether an item is 'completed', 'ongoing', or 'upcoming'
  const getEventTimeStatus = (item: TimelineItem) => {
    if (currentHour >= item.endHour) {
      return 'completed';
    } else if (currentHour >= item.startHour && currentHour < item.endHour) {
      return 'ongoing';
    } else {
      return 'upcoming';
    }
  };

  // Official festival hours overview helper
  const isFestivalEnded = currentHour >= 21.25;
  const isFestivalYetToStart = currentHour < 9.5;

  return (
    <div className="space-y-4">
      {/* 1. Official Festival Hours Banner */}
      <div className="bg-slate-900 text-white rounded-3xl p-5 shadow-sm overflow-hidden relative border border-slate-800">
        <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-600/30 rounded-full blur-3xl -mr-12 -mt-12"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-rose-500/10 rounded-full blur-2xl -ml-6 -mb-6"></div>

        <div className="relative z-15 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] text-indigo-300 font-extrabold tracking-widest block uppercase">OFFICIAL SHEETS</span>
            <h3 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5">
              축제 정식 종합 시간 안내
              <Sparkles className="w-4.5 h-4.5 text-yellow-400 shrink-0" />
            </h3>
            <p className="text-xs text-slate-300">
              오늘 하루 동안 캠퍼스 전역에서 펼쳐지는 시간별 스테이지 일정입니다.
            </p>
          </div>

          <div className="inline-flex flex-col items-center bg-white/10 backdrop-blur-md py-2.5 px-4 rounded-2xl border border-white/10 shrink-0 text-center">
            <span className="text-[10px] font-bold text-slate-300 block">총 축제 개방시간</span>
            <span className="text-base font-black text-rose-300 font-mono tracking-wide">09:30 - 21:15</span>
            <div className="mt-1 flex items-center gap-1">
              <span className={`w-1.5 h-1.5 rounded-full ${isFestivalEnded ? 'bg-slate-400' : isFestivalYetToStart ? 'bg-amber-400' : 'bg-emerald-400'} inline-block`}></span>
              <span className="text-[9px] text-slate-200 font-bold">
                {isFestivalEnded ? '축제 종료됨' : isFestivalYetToStart ? '개장 준비중' : '축제 진행 중'}
              </span>
            </div>
          </div>
        </div>

        {/* Progress gauge */}
        <div className="mt-4 pt-4 border-t border-slate-800 space-y-2 relative z-10">
          <div className="flex justify-between text-[10px] text-slate-400 font-bold">
            <span>09:30 AM (시작)</span>
            <span>현재 타임 라인 게이지</span>
            <span>09:15 PM (종료)</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-gradient-to-r from-indigo-500 via-rose-500 to-amber-500 h-full rounded-full transition-all duration-300"
              style={{ 
                width: `${Math.max(0, Math.min(100, ((currentHour - 9.5) / (21.25 - 9.5)) * 100))}%` 
              }}
            ></div>
          </div>
        </div>
      </div>

      {/* 2. Timeline Category Tabs */}
      <div className="bg-white rounded-3xl p-3 shadow-sm border border-slate-100 flex gap-1">
        <button
          onClick={() => setActiveFilter('all')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeFilter === 'all'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-500 hover:bg-slate-50'
          }`}
          id="timeline-filter-all"
        >
          ⏱️ 전체 시간
        </button>
        <button
          onClick={() => setActiveFilter('band')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeFilter === 'band'
              ? 'bg-purple-600 text-white shadow-sm'
              : 'text-slate-500 hover:bg-slate-50'
          }`}
          id="timeline-filter-band"
        >
          🎸 밴드 공연
        </button>
        <button
          onClick={() => setActiveFilter('booth')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeFilter === 'booth'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-500 hover:bg-slate-50'
          }`}
          id="timeline-filter-booth"
        >
          🎪 부스 오픈
        </button>
        <button
          onClick={() => setActiveFilter('general')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeFilter === 'general'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-500 hover:bg-slate-50'
          }`}
          id="timeline-filter-events"
        >
          🎉 공식 행사
        </button>
      </div>

      {/* 3. Timeline Chronological Flow layout */}
      <div className="relative pl-6 border-l-2 border-slate-200 space-y-6 pt-2 pb-6">
        {filteredItems.map((item, index) => {
          const status = getEventTimeStatus(item);
          const typeLabel = item.type === 'band' ? '밴드 콘서트' : item.type === 'booth' ? '부스 일정' : '공식 이벤트';

          return (
            <div 
              key={item.id} 
              className={`relative transition-all duration-300 ${
                status === 'ongoing' 
                  ? 'scale-101 border-rose-200 z-10' 
                  : status === 'completed' 
                  ? 'opacity-65' 
                  : ''
              }`}
            >
              {/* Timeline dot */}
              <div className={`absolute -left-10 top-2 w-7 h-7 rounded-full border-4 flex items-center justify-center shadow-md transition-all ${
                status === 'ongoing'
                  ? 'bg-rose-500 border-rose-100 text-white animate-pulse'
                  : status === 'completed'
                  ? 'bg-slate-300 border-white text-slate-500'
                  : 'bg-white border-slate-200 text-slate-400'
              }`}>
                {item.type === 'band' ? (
                  <Music className="w-3.5 h-3.5 shrink-0" />
                ) : item.type === 'booth' ? (
                  <Coffee className="w-3.5 h-3.5 shrink-0" />
                ) : (
                  <Calendar className="w-3.5 h-3.5 shrink-0" />
                )}
              </div>

              {/* Card representation */}
              <div className={`bg-white rounded-3xl p-5 shadow-sm border transition-all ${
                status === 'ongoing'
                  ? 'border-rose-500 shadow-md ring-4 ring-rose-500/5'
                  : 'border-slate-100'
              }`}>
                <div className="flex items-start justify-between flex-wrap gap-2.5 mb-2">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-black text-rose-500 font-mono tracking-wide bg-rose-50 py-0.5 px-2.5 rounded-lg border border-rose-100/50">
                      {item.timeStr}
                    </span>
                    
                    {status === 'ongoing' && (
                      <span className="bg-red-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded animate-pulse">
                        LIVE 진행중
                      </span>
                    )}
                    {status === 'completed' && (
                      <span className="bg-slate-100 text-slate-400 text-[9px] font-bold px-1.5 py-0.5 rounded">
                        종료됨
                      </span>
                    )}
                  </div>

                  <span className={`text-[9px] font-black px-2 py-0.5 rounded-full ${
                    item.type === 'band'
                      ? 'bg-purple-50 text-purple-700 border border-purple-100'
                      : item.type === 'booth'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                      : 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                  }`}>
                    {typeLabel}
                  </span>
                </div>

                <div className="space-y-1">
                  <h4 className="font-extrabold text-slate-800 text-base flex items-center gap-1.5">
                    {item.title}
                  </h4>
                  <p className="text-xs text-slate-400 font-semibold">{item.subtitle}</p>
                </div>

                <p className="text-xs text-slate-500 mt-2.5 leading-relaxed font-normal">
                  {item.description}
                </p>

                <div className="mt-3.5 pt-3 border-t border-slate-50 flex items-center justify-between text-[11px] text-slate-500">
                  <div className="flex items-center gap-1 font-medium">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{item.location}</span>
                  </div>
                  
                  {item.type === 'band' && status === 'ongoing' && (
                    <div className="flex items-center gap-1 animate-pulse text-purple-600 font-bold">
                      <Music className="w-3 h-3 text-purple-600 fill-purple-600" />
                      <span>무대 라이브 음압 절정!</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
