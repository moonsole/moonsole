import React, { useState, useMemo } from 'react';
import { MapPin, Info, Compass, Sparkles, Filter, CheckCircle2, AlertTriangle, Eye } from 'lucide-react';
import { Booth } from '../types';
import { BOOTHS } from '../data';

interface BoothMapProps {
  currentHour: number;
  highlightedBoothId: string | null;
  onSelectBooth: (booth: Booth | null) => void;
}

interface MapCoordinates {
  [id: string]: { x: number; y: number };
}

// Fixed coordinates in percentages on our custom scale (0 to 100)
const COORDINATES: MapCoordinates = {
  // Area A (Bottom-left grass)
  b1: { x: 25, y: 70 },
  b2: { x: 15, y: 80 },
  b3: { x: 35, y: 78 },
  b4: { x: 18, y: 62 },
  
  // Area B (Right sports plaza)
  b5: { x: 78, y: 28 },
  b6: { x: 86, y: 40 },
  b7: { x: 74, y: 52 },
  b8: { x: 88, y: 63 },
  
  // Area C (Top gallery road)
  b9: { x: 26, y: 22 },
  b10: { x: 38, y: 28 },
  b11: { x: 50, y: 18 },
  b12: { x: 18, y: 36 }
};

export default function BoothMap({ currentHour, highlightedBoothId, onSelectBooth }: BoothMapProps) {
  const [selectedZoneFilter, setSelectedZoneFilter] = useState<'ALL' | 'A' | 'B' | 'C'>('ALL');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<'ALL' | 'OPEN'>('ALL');
  const [selectedBooth, setSelectedBooth] = useState<Booth | null>(
    highlightedBoothId ? (BOOTHS.find(b => b.id === highlightedBoothId) || null) : null
  );

  // Sync state if highlighted from external parent (like clicking a shortcut in Home or List)
  React.useEffect(() => {
    if (highlightedBoothId) {
      const b = BOOTHS.find(x => x.id === highlightedBoothId);
      if (b) {
        setSelectedBooth(b);
      }
    }
  }, [highlightedBoothId]);

  // Helper: check if booth is open at current simulated hour
  const isBoothOpenNow = (booth: Booth) => {
    return currentHour >= booth.startHour && currentHour < booth.endHour;
  };

  // Filtered booth list for pins
  const visibleBooths = useMemo(() => {
    return BOOTHS.filter((booth) => {
      const zoneMatch = selectedZoneFilter === 'ALL' || booth.zone === selectedZoneFilter;
      const isOpen = isBoothOpenNow(booth);
      const statusMatch = selectedStatusFilter === 'ALL' || (selectedStatusFilter === 'OPEN' && isOpen);
      return zoneMatch && statusMatch;
    });
  }, [selectedZoneFilter, selectedStatusFilter, currentHour]);

  const handlePinClick = (booth: Booth) => {
    setSelectedBooth(booth);
    onSelectBooth(booth);
  };

  const handleCloseDrawer = () => {
    setSelectedBooth(null);
    onSelectBooth(null);
  };

  return (
    <div className="space-y-4">
      {/* Header and Filter bar */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-rose-50 text-rose-600 rounded-xl">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-800 text-base">캠퍼스 종합 부스 맵</h3>
              <p className="text-xs text-slate-500">A, B, C 구역 터치로 구역별 부스 위치 탐색</p>
            </div>
          </div>
          
          <div className="flex items-center gap-1 text-[11px] bg-slate-50 py-1 px-2.5 rounded-lg border border-slate-100 font-bold text-slate-500">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-ping"></span>
            <span>{visibleBooths.filter(isBoothOpenNow).length}개 영업중</span>
          </div>
        </div>

        {/* Interactive Filters */}
        <div className="space-y-3">
          <div>
            <span className="text-[11px] font-bold text-slate-400 block mb-1.5">구역 필터</span>
            <div className="grid grid-cols-4 gap-1.5">
              {(['ALL', 'A', 'B', 'C'] as const).map((z) => (
                <button
                  key={z}
                  onClick={() => setSelectedZoneFilter(z)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                    selectedZoneFilter === z
                      ? 'bg-slate-900 border-slate-900 text-white shadow-sm'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {z === 'ALL' ? '전체 구역' : `${z}구역`}
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setSelectedStatusFilter(selectedStatusFilter === 'ALL' ? 'OPEN' : 'ALL')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                selectedStatusFilter === 'OPEN'
                  ? 'bg-emerald-500 border-emerald-500 text-white shadow-sm'
                  : 'bg-slate-50 border-slate-200 text-slate-600'
              }`}
            >
              <Filter className="w-3.5 h-3.5" />
              <span>실시간 오픈한 부스만 보기</span>
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Map Canvas Container */}
      <div className="relative bg-teal-50/20 border-2 border-slate-100 rounded-3xl overflow-hidden aspect-[4/3] w-full shadow-md bg-cover bg-center">
        {/* Customized Festival Background Grid Representation */}
        <svg viewBox="0 0 100 75" className="absolute inset-0 w-full h-full select-none">
          {/* Paths and Landscapes */}
          {/* Center Lake/Pond decoration */}
          <ellipse cx="50" cy="40" rx="14" ry="10" fill="#E0F2FE" stroke="#BAE6FD" strokeWidth="0.5" />
          <text x="50" y="41" textAnchor="middle" fill="#0369A1" fontSize="1.8" fontWeight="bold">인공호수</text>

          {/* Paths/Road lines connecting campuses */}
          <path d="M 25,25 Q 50,22 75,25" fill="none" stroke="#E2E8F0" strokeWidth="2.5" strokeDasharray="1 1" />
          <path d="M 25,25 Q 20,48 25,70" fill="none" stroke="#E2E8F0" strokeWidth="2.5" strokeDasharray="1 1" />
          <path d="M 75,25 Q 80,48 75,70" fill="none" stroke="#E2E8F0" strokeWidth="2.5" strokeDasharray="1 1" />
          <path d="M 25,70 H 75" fill="none" stroke="#E2E8F0" strokeWidth="2.5" strokeDasharray="1 1" />

          {/* Area A Zone boundary (Bottom-Left) */}
          <rect x="5" y="52" width="40" height="30" rx="6" fill="#F0FDF4" stroke="#BBF7D0" strokeWidth="0.5" opacity="0.8" />
          <text x="25" y="57" textAnchor="middle" fill="#15803D" fontSize="3" fontWeight="black" pointerEvents="none">
            A구역: 먹거리 푸드 존 🍔
          </text>
          
          {/* Area B Zone boundary (Right) */}
          <rect x="62" y="15" width="33" height="52" rx="6" fill="#FFFBEB" stroke="#FDE68A" strokeWidth="0.5" opacity="0.8" />
          <text x="78" y="21" textAnchor="middle" fill="#B45309" fontSize="3" fontWeight="black" pointerEvents="none">
            B구역: 액티비티 존 🎯
          </text>

          {/* Area C Zone boundary (Top-Left) */}
          <rect x="10" y="10" width="48" height="30" rx="6" fill="#F5F3FF" stroke="#DDD6FE" strokeWidth="0.5" opacity="0.8" />
          <text x="34" y="15" textAnchor="middle" fill="#6D28D9" fontSize="3" fontWeight="black" pointerEvents="none">
            C구역: 전시 & 굿즈 존 🎨
          </text>

          {/* Compass / Key Points */}
          <g transform="translate(90, 8)">
            <circle cx="0" cy="0" r="4" fill="white" stroke="#CBD5E1" strokeWidth="0.5" />
            <line x1="0" y1="-3.5" x2="0" y2="3.5" stroke="#E2E8F0" />
            <line x1="-3.5" y1="0" x2="3.5" y2="0" stroke="#E2E8F0" />
            <polygon points="0,-3 1.2,-0.5 -1.2,-0.5" fill="#EF4444" />
            <polygon points="0,3 1.2,0.5 -1.2,0.5" fill="#94A3B8" />
            <text x="0" y="-4.5" textAnchor="middle" fontSize="1.5" fill="#64748B" fontWeight="bold">N</text>
          </g>
        </svg>

        {/* Booth Markers placed using absolute coordinate overlays */}
        {visibleBooths.map((booth) => {
          const coords = COORDINATES[booth.id] || { x: 50, y: 35 };
          const isOpen = isBoothOpenNow(booth);
          const isSelected = selectedBooth?.id === booth.id;

          return (
            <button
              key={booth.id}
              onClick={() => handlePinClick(booth)}
              className="absolute group -translate-x-1/2 -translate-y-1/2 transition-transform duration-300 active:scale-95"
              style={{ left: `${coords.x}%`, top: `${coords.y}%` }}
              title={booth.name}
            >
              {/* Badge Overlay showing Icon */}
              <div className="relative">
                {/* Ping wave for OPEN active booths */}
                {isOpen && (
                  <span className="absolute -inset-1 rounded-full bg-emerald-500/40 animate-ping opacity-75"></span>
                )}

                {/* Main pin body */}
                <div
                  className={`w-9 h-9 rounded-2xl flex items-center justify-center shadow-lg border-2 transition-all ${
                    isSelected
                      ? 'bg-rose-600 border-white text-white scale-120 ring-4 ring-rose-500/30 font-bold z-30'
                      : isOpen
                      ? 'bg-emerald-500 border-white text-white hover:scale-110 z-10'
                      : 'bg-slate-300 border-slate-100 text-slate-600 hover:scale-110 z-0'
                  }`}
                >
                  <span className="text-[10px] font-extrabold font-mono">
                    {booth.zone}{booth.id.replace('b', '')}
                  </span>
                </div>

                {/* Sub-label bubble for selected or close hover */}
                {(isSelected) && (
                  <div className="absolute top-10 left-1/2 -translate-x-1/2 bg-slate-900 text-white font-bold text-[10px] py-1 px-2.5 rounded-lg whitespace-nowrap shadow-xl z-40 border border-slate-700 animate-fade-in">
                    {booth.name} ({isOpen ? '영업중' : '종료'})
                  </div>
                )}
              </div>
            </button>
          );
        })}

        {/* Map Guidelines Panel */}
        <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-3 py-2 rounded-2xl border border-slate-200/50 shadow-sm text-[10px] pointer-events-none space-y-1 z-10">
          <div className="font-bold text-slate-700 mb-1">지도 범례</div>
          <div className="flex items-center gap-1.5 text-slate-600 font-medium">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
            <span>영업중 (Open)</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-600 font-medium">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-300 inline-block"></span>
            <span>운영 종료/예정 (Closed)</span>
          </div>
        </div>
      </div>

      {/* Selected Booth Details Slate Drawer */}
      {selectedBooth ? (
        <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xl space-y-4 animate-slide-up">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full ${
                  selectedBooth.zone === 'A'
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                    : selectedBooth.zone === 'B'
                    ? 'bg-amber-50 text-amber-700 border border-amber-100'
                    : 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                }`}>
                  {selectedBooth.zoneName}
                </span>

                {isBoothOpenNow(selectedBooth) ? (
                  <span className="bg-emerald-100 text-emerald-800 text-[10px] px-2 py-0.5 rounded-md font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    운영중
                  </span>
                ) : (
                  <span className="bg-slate-100 text-slate-500 text-[10px] px-2 py-0.5 rounded-md font-bold flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" />
                    운영외 시간
                  </span>
                )}
              </div>
              
              <h4 className="font-black text-slate-800 text-lg">{selectedBooth.name}</h4>
              <p className="text-xs text-slate-500 leading-relaxed">{selectedBooth.description}</p>
            </div>
            
            <button
              onClick={handleCloseDrawer}
              className="text-xs font-bold text-slate-400 hover:text-slate-600 bg-slate-100 p-2 rounded-full transition-all shrink-0"
              id="close-map-drawer-btn"
            >
              닫기
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
            <div>
              <span className="text-slate-400 font-medium block">⏰ 운영 시간</span>
              <span className="font-bold text-slate-700">{selectedBooth.time}</span>
            </div>
            <div>
              <span className="text-slate-400 font-medium block">📍 세부 위치</span>
              <span className="font-bold text-slate-700">{selectedBooth.locationDesc}</span>
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-[11px] font-bold text-slate-400 block">🛍️ 주요 메뉴 또는 체험 목록</span>
            <div className="space-y-1">
              {selectedBooth.menuOrActivity.map((menu, idx) => (
                <div key={idx} className="flex justify-between items-center text-xs text-slate-700 py-1.5 px-2 bg-slate-50/50 rounded-lg font-medium">
                  <span>{menu.split(' - ')[0]}</span>
                  <span className="font-bold text-slate-900">{menu.split(' - ')[1] || '체험가능'}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-1">
            {selectedBooth.tags.map((tag, idx) => (
              <span key={idx} className="text-[10px] text-slate-500 bg-slate-100 py-1 px-2.5 rounded-lg font-medium">
                #{tag}
              </span>
            ))}
          </div>
        </div>
      ) : (
        <div className="bg-slate-50 border border-slate-200/60 rounded-3xl p-6 text-center text-xs text-slate-400 flex flex-col items-center justify-center gap-2">
          <Info className="w-5 h-5 text-slate-300" />
          <p>지도상의 번호 핀을 탭하시면 영수증 형태의 상세 푸드메뉴 및 체험 코스를 확인할 수 있습니다.</p>
        </div>
      )}
    </div>
  );
}
