export interface Booth {
  id: string;
  name: string;
  description: string;
  zone: 'A' | 'B' | 'C';
  zoneName: string;
  category: 'food' | 'play' | 'goods' | 'exhibit';
  tags: string[];
  time: string;
  startHour: number; // e.g. 10 for 10:00
  endHour: number;   // e.g. 17 for 17:00
  locationDesc: string;
  iconName: string;
  menuOrActivity: string[];
}

export interface FestivalEvent {
  id: string;
  title: string;
  time: string;
  startHour: number;
  endHour: number;
  location: string;
  description: string;
  imageUrl: string;
  badge: string;
  type: 'live' | 'event' | 'opening';
}

export interface TimelineItem {
  id: string;
  timeStr: string;
  startHour: number;
  endHour: number;
  title: string;
  type: 'general' | 'band' | 'booth';
  subtitle: string;
  description: string;
  location: string;
}
