import React, { useState, useEffect } from 'react';
import { 
  Home as HomeIcon, 
  Map as MapIcon, 
  List as ListIcon, 
  Clock as ClockIcon, 
  Sparkles, 
  Calendar, 
  Flame, 
  Share2, 
  ArrowRight, 
  Music, 
  MapPin, 
  Users,
  Compass,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Data imports
import { BOOTHS, EVENTS } from './data';
import { Booth } from './types';

// Components
import VirtualTimeController from './components/VirtualTimeController';
import KakaoShareCard from './components/KakaoShareCard';
import BoothMap from './components/BoothMap';
import BoothList from './components/BoothList';
import FestivalTimeline from './components/FestivalTimeline';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'map' | 'list' | 'time'>('home');
  
  // Real-time vs Simulation State
  const [useRealTime, setUseRealTime] = useState<boolean>(false);
  const [currentHour, setCurrentHour] = useState<number>(14.5); // Defaults to 2:30 PM (excellent daytime activity)
  
  // Highlighted booth on map
  const [selectedBoothOnMapId, setSelectedBoothOnMapId] = useState<string | null>(null);

  // Sync real-time clock to decimal format if enabled
  useEffect(() => {
    if (!useRealTime) return;

    const updateTime = () => {
      const now = new Date();
      // Combine hours and fractional minutes
      const hoursDecimal = now.getHours() + now.getMinutes() / 60;
      // Clamp to our festival timeline slider range (09:00 - 22:00) for ideal testing,
      // but let real-time show exactly what time it is
      setCurrentHour(hoursDecimal);
    };

    updateTime();
    const interval = setInterval(updateTime, 10000); // Update every 10 seconds
    return () => clearInterval(interval);
  }, [useRealTime]);

  const handleHourChange = (hour: number) => {
    if (!useRealTime) {
      setCurrentHour(hour);
    }
  };

  const handleToggleRealTime = (val: boolean) => {
    setUseRealTime(val);
  };

  // Navigations bridging
  const handleGoToMapWithBooth = (boothId: string) => {
    setSelectedBoothOnMapId(boothId);
    setActiveTab('map');
  };

  // Check if a specific event is active based on current hour
  const isEventHappening = (event: typeof EVENTS[0]) => {
    return currentHour >= event.startHour && currentHour < event.endHour;
  };

  // Formatted date string (today constant context for UI)
  const todayKRString = '2026년 5월 20일 (토)';

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between max-w-md mx-auto shadow-2xl relative border-x border-slate-100 pb-20">
      
      {/* GLOW DECORATIONS */}
      <div className="absolute top-0 left-10 w-44 h-44 bg-rose-300 rounded-full blur-3xl opacity-20 pointer-events-none -mt-10"></div>
      <div className="absolute top-80 right-4 w-48 h-48 bg-indigo-300 rounded-full blur-3xl opacity-25 pointer-events-none"></div>

      {/* GLOBAL HEADER */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md px-5 py-4 border-b border-slate-100 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-2">
          <div className="w-8.5 h-8.5 bg-gradient-to-tr from-rose-500 to-indigo-600 rounded-xl flex items-center justify-center text-white font-extrabold text-sm shadow-md animate-pulse">
            ✨
          </div>
          <div>
            <h1 className="font-black text-slate-800 text-sm tracking-tight">청춘 나래 축제 가이드</h1>
            <p className="text-[10px] text-slate-400 font-bold flex items-center gap-1">
              <Calendar className="w-2.5 h-2.5 text-rose-500" />
              <span>{todayKRString}</span>
            </p>
          </div>
        </div>

        <div className="p-1 px-2.5 bg-slate-100 text-[10px] font-black tracking-wide text-slate-600 rounded-lg border border-slate-200 uppercase">
          LIVE MAP
        </div>
      </header>

      {/* MAIN CONTAINER AND ROUTER */}
      <main className="flex-1 p-4 space-y-5 relative z-10 overflow-y-auto">
        
        {/* Persistent Floating Virtual Hour Controller on all pages inside standard header expansion */}
        <div className="mb-2">
          <VirtualTimeController
            currentHour={currentHour}
            useRealTime={useRealTime}
            onHourChange={handleHourChange}
            onToggleRealTime={handleToggleRealTime}
          />
        </div>

        {activeTab === 'home' && (
          <motion.div 
            initial={{ opacity: 0, y: 15 }} 
            animate={{ opacity: 1, y: 0 }} 
            className="space-y-5"
          >
            {/* 1. 오늘 열리는 행사 (Today's Events / Highlights) at the absolute top */}
            <div className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-extrabold text-slate-800">🔥 오늘 열리는 하이라이트 행사</span>
                </div>
                <span className="text-[10px] text-slate-400 font-semibold">전체 {EVENTS.length}개</span>
              </div>

              {/* Event card slider/carousel */}
              <div className="space-y-4">
                {EVENTS.map((event) => {
                  const active = isEventHappening(event);
                  const statusLabel = currentHour >= event.endHour ? '축제 종료됨' : active ? '지금 진행중!' : '오늘 상시/예정';

                  return (
                    <div 
                      key={event.id}
                      className="bg-white rounded-3xl overflow-hidden border border-slate-100 shadow-sm relative group"
                    >
                      {/* Image header with details overlay */}
                      <div className="relative h-44 w-full bg-slate-100 overflow-hidden">
                        <img 
                          src={event.imageUrl} 
                          alt={event.title} 
                          className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/45 to-transparent"></div>
                        
                        {/* Highlights overlay badges */}
                        <div className="absolute top-3.5 left-3.5 flex gap-1.5">
                          <span className="bg-rose-500 text-white text-[9px] font-black px-2.5 py-1 rounded-lg tracking-wider uppercase shadow-md">
                            {event.badge}
                          </span>
                          
                          <span className={`text-[9px] font-black px-2.5 py-1 rounded-lg shadow-md ${
                            active 
                              ? 'bg-emerald-500 text-white animate-pulse' 
                              : currentHour >= event.endHour
                              ? 'bg-slate-700 text-slate-300'
                              : 'bg-white/90 text-slate-700 backdrop-blur-md'
                          }`}>
                            {statusLabel}
                          </span>
                        </div>

                        {/* Title overlay at bottom of picture */}
                        <div className="absolute bottom-3.5 left-3.5 right-3.5">
                          <span className="text-[10px] text-rose-300 font-extrabold tracking-wider block mb-0.5">
                            {event.time} | {event.location}
                          </span>
                          <h4 className="text-base font-black text-white tracking-tight">
                            {event.title}
                          </h4>
                        </div>
                      </div>

                      {/* Info & action footer */}
                      <div className="p-4 bg-white space-y-3">
                        <p className="text-xs text-slate-500 leading-relaxed font-normal">
                          {event.description}
                        </p>
                        
                        <div className="flex gap-2.5 text-[11px] bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                          <div className="flex items-center gap-1.5 text-slate-500 font-semibold">
                            <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                            <span>{event.location}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 2. 그 밑에는 카카오톡으로 공유할 수 있는 버튼 카드 */}
            <KakaoShareCard festivalName="청춘 나래 축제" />

            {/* 3. 그 밑에는 타임라인 페이지랑 지도 페이지로 갈 수 있는 버튼 단락 */}
            <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-101/60 space-y-3">
              <div>
                <h3 className="font-extrabold text-slate-800 text-sm">🧭 빠른 페이지 바로가기</h3>
                <p className="text-[11px] text-slate-400">축제 지도를 보거나 운영 타임테이블로 즉시 이동하세요.</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {/* Goto Timeline shortcut button */}
                <button
                  onClick={() => setActiveTab('time')}
                  className="flex flex-col items-start p-4 bg-indigo-50/50 hover:bg-indigo-50 border border-indigo-100/40 rounded-2xl text-left transition-all active:scale-98"
                  id="goto-time-shortcut"
                >
                  <div className="p-2 bg-indigo-500 text-white rounded-xl mb-3 shadow-xs">
                    <ClockIcon className="w-5 h-5" />
                  </div>
                  <span className="font-extrabold text-slate-800 text-xs block">공연 타임라인 보기</span>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">밴드공연, 부스 시간표</span>
                </button>

                {/* Goto Map shortcut button */}
                <button
                  onClick={() => setActiveTab('map')}
                  className="flex flex-col items-start p-4 bg-rose-50/50 hover:bg-rose-50 border border-rose-100/40 rounded-2xl text-left transition-all active:scale-98"
                  id="goto-map-shortcut"
                >
                  <div className="p-2 bg-rose-500 text-white rounded-xl mb-3 shadow-xs">
                    <MapIcon className="w-5 h-5" />
                  </div>
                  <span className="font-extrabold text-slate-800 text-xs block">종합 부스 맵 보기</span>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">A, B, C 구역별 배치도</span>
                </button>
              </div>
            </div>

            {/* Footer decoration info */}
            <div className="text-center pt-2 pb-6 space-y-1">
              <p className="text-[10px] text-slate-400 font-bold">© 2026 청춘나래축제 준비단 기획실</p>
              <p className="text-[9px] text-slate-300">본 어플리케이션은 축제 부스 운영 및 일정을 모바일로 쾌적하게 안내합니다.</p>
            </div>
          </motion.div>
        )}

        {activeTab === 'map' && (
          <motion.div 
            initial={{ opacity: 0, y: 15 }} 
            animate={{ opacity: 1, y: 0 }}
            className="space-y-1"
          >
            <BoothMap 
              currentHour={currentHour}
              highlightedBoothId={selectedBoothOnMapId}
              onSelectBooth={(b) => {
                if (!b) setSelectedBoothOnMapId(null);
              }}
            />
          </motion.div>
        )}

        {activeTab === 'list' && (
          <motion.div 
            initial={{ opacity: 0, y: 15 }} 
            animate={{ opacity: 1, y: 0 }}
            className="space-y-1"
          >
            <BoothList 
              currentHour={currentHour}
              onGoToMapWithBooth={handleGoToMapWithBooth}
            />
          </motion.div>
        )}

        {activeTab === 'time' && (
          <motion.div 
            initial={{ opacity: 0, y: 15 }} 
            animate={{ opacity: 1, y: 0 }}
            className="space-y-1"
          >
            <FestivalTimeline 
              currentHour={currentHour}
            />
          </motion.div>
        )}

      </main>

      {/* BOTTOM TAB NAVIGATION BAR (하단 바) */}
      <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white/95 backdrop-blur-md border-t border-slate-200/60 z-40 px-5 py-2.5 shadow-xl flex items-center justify-between rounded-t-3xl">
        {/* Home Tab */}
        <button
          onClick={() => {
            setActiveTab('home');
            setSelectedBoothOnMapId(null);
          }}
          className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 transition-all ${
            activeTab === 'home' ? 'text-rose-500 scale-102 font-bold' : 'text-slate-400 hover:text-slate-600'
          }`}
          id="tab-home"
        >
          <HomeIcon className="w-5.5 h-5.5 shrink-0" />
          <span className="text-[10px] tracking-tight">홈</span>
        </button>

        {/* Map Tab */}
        <button
          onClick={() => {
            setActiveTab('map');
          }}
          className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 transition-all ${
            activeTab === 'map' ? 'text-rose-500 scale-102 font-bold' : 'text-slate-400 hover:text-slate-600'
          }`}
          id="tab-map"
        >
          <MapIcon className="w-5.5 h-5.5 shrink-0" />
          <span className="text-[10px] tracking-tight font-medium">지도 (부스맵)</span>
        </button>

        {/* List Tab */}
        <button
          onClick={() => {
            setActiveTab('list');
            setSelectedBoothOnMapId(null);
          }}
          className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 transition-all ${
            activeTab === 'list' ? 'text-rose-500 scale-102 font-bold' : 'text-slate-400 hover:text-slate-600'
          }`}
          id="tab-list"
        >
          <ListIcon className="w-5.5 h-5.5 shrink-0" />
          <span className="text-[10px] tracking-tight">부스 정보</span>
        </button>

        {/* Time Tab */}
        <button
          onClick={() => {
            setActiveTab('time');
            setSelectedBoothOnMapId(null);
          }}
          className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 transition-all ${
            activeTab === 'time' ? 'text-rose-500 scale-102 font-bold' : 'text-slate-400 hover:text-slate-600'
          }`}
          id="tab-time"
        >
          <ClockIcon className="w-5.5 h-5.5 shrink-0" />
          <span className="text-[10px] tracking-tight">일정 타임라인</span>
        </button>
      </nav>
      
    </div>
  );
}
